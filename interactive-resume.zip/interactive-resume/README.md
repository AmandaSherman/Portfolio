# Interactive Resume

A Pen created on CodePen.io. Original URL: [https://codepen.io/becckitt/pen/LEjovg](https://codepen.io/becckitt/pen/LEjovg).

Played a little bit of hide and seek with my resume. Used the code for the flashlight effect from here:http://codepen.io/arroinua/pen/bBxgm